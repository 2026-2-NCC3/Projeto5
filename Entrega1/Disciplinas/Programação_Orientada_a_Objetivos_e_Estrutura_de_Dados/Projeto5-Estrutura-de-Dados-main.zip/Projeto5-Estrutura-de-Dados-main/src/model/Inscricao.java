package model;

public class Inscricao {

    private String id;
    private Aluno aluno;
    private Curso curso;
    private String status;
    private String dataParticipacao;
    private int pontosObtidos;

    public Inscricao(String id, Aluno aluno, Curso curso, String status,
                     String dataParticipacao, int pontosObtidos) {

        this.id = id;
        this.aluno = aluno;
        this.curso = curso;
        this.status = status;
        this.dataParticipacao = dataParticipacao;
        this.pontosObtidos = pontosObtidos;
    }

    public String getId() {
        return id;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public Curso getCurso() {
        return curso;
    }

    public String getStatus() {
        return status;
    }

    public String getDataParticipacao() {
        return dataParticipacao;
    }

    public int getPontosObtidos() {
        return pontosObtidos;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setDataParticipacao(String dataParticipacao) {
        this.dataParticipacao = dataParticipacao;
    }

    public void setPontosObtidos(int pontosObtidos) {
        this.pontosObtidos = pontosObtidos;
    }
}