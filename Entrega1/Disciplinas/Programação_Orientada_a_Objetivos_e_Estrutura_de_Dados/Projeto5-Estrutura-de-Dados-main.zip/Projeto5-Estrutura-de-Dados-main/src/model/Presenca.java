package model;

public class Presenca {

    private String id;
    private Aluno aluno;
    private Atividade atividade;
    private boolean presente;
    private String dataPresenca;

    public Presenca(String id, Aluno aluno, Atividade atividade,
                    boolean presente, String dataPresenca) {

        this.id = id;
        this.aluno = aluno;
        this.atividade = atividade;
        this.presente = presente;
        this.dataPresenca = dataPresenca;
    }

    public String getId() {
        return id;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public Atividade getAtividade() {
        return atividade;
    }

    public boolean isPresente() {
        return presente;
    }

    public String getDataPresenca() {
        return dataPresenca;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public void setAtividade(Atividade atividade) {
        this.atividade = atividade;
    }

    public void setPresente(boolean presente) {
        this.presente = presente;
    }

    public void setDataPresenca(String dataPresenca) {
        this.dataPresenca = dataPresenca;
    }
}