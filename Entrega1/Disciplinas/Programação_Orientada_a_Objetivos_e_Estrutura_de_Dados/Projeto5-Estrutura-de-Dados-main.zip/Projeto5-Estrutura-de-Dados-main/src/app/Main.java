package app;

import model.Aluno;
import model.Curso;
import service.AlunoService;
import service.CursoService;

public class Main {

    public static void main(String[] args) {

        AlunoService alunoService = new AlunoService();
        CursoService cursoService = new CursoService();

        Aluno aluno1 = new Aluno(
                "1",
                "Arthur Daher",
                "FECAP",
                "3º ano",
                "2026",
                "São Paulo",
                "11999999999",
                100,
                "Iniciante",
                2,
                0,
                false
        );

        Aluno aluno2 = new Aluno(
                "2",
                "Katie Prado",
                "FECAP",
                "3º ano",
                "2026",
                "São Paulo",
                "11888888888",
                150,
                "Intermediário",
                3,
                1,
                false
        );

        alunoService.cadastrar(aluno1);
        alunoService.cadastrar(aluno2);

        System.out.println("=== ALUNOS CADASTRADOS ===");

        for (Aluno aluno : alunoService.listar()) {
            System.out.println(aluno.getNomeCompleto());
        }

        System.out.println("\n=== BUSCA POR ID ===");

        Aluno alunoEncontrado = alunoService.localizarPorId("1");

        if (alunoEncontrado != null) {
            System.out.println("Aluno encontrado: "
                    + alunoEncontrado.getNomeCompleto());
        }

        System.out.println("\n=== EDIÇÃO ===");

        alunoService.editar(
                "1",
                "Arthur Daher Atualizado",
                "Nova Escola"
        );

        System.out.println(
                alunoService.localizarPorId("1").getNomeCompleto()
        );

        System.out.println("\n=== ORDENAÇÃO POR NOME ===");

        alunoService.ordenarPorNome();

        for (Aluno aluno : alunoService.listar()) {
            System.out.println(aluno.getNomeCompleto());
        }

        System.out.println("\n=== REMOÇÃO ===");

        alunoService.remover("2");

        for (Aluno aluno : alunoService.listar()) {
            System.out.println(aluno.getNomeCompleto());
        }

        Curso curso1 = new Curso(
                "1",
                "Introdução à Tecnologia",
                "Curso introdutório de tecnologia.",
                "São Paulo",
                "25/09/2026",
                "18:00",
                30,
                28,
                100,
                true,
                "Tecnologia",
                true
        );

        cursoService.cadastrar(curso1);

        System.out.println("\n=== CURSOS ===");

        for (Curso curso : cursoService.listar()) {
            System.out.println(curso.getTitulo());
        }
    }
}