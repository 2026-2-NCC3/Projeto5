package service;

import java.util.ArrayList;
import java.util.List;

import model.Inscricao;

public class InscricaoService {

    private List<Inscricao> inscricoes;

    public InscricaoService() {
        inscricoes = new ArrayList<>();
    }

    public void cadastrar(Inscricao inscricao) {
        inscricoes.add(inscricao);
    }

    public List<Inscricao> listar() {
        return inscricoes;
    }

    public Inscricao localizarPorId(String id) {
        for (Inscricao inscricao : inscricoes) {
            if (((Inscricao) inscricao).getId().equals(id)) {
                return inscricao;
            }
        }

        return null;
    }

    public boolean editarStatus(String id, String novoStatus) {
        Inscricao inscricao = localizarPorId(id);

        if (inscricao != null) {
            inscricao.setStatus(novoStatus);
            return true;
        }

        return false;
    }

    public boolean remover(String id) {
        Inscricao inscricao = localizarPorId(id);

        if (inscricao != null) {
            inscricoes.remove(inscricao);
            return true;
        }

        return false;
    }
}