package service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import model.Curso;

public class CursoService {

    private List<Curso> cursos;

    public CursoService() {
        cursos = new ArrayList<>();
    }

    public void cadastrar(Curso curso) {
        cursos.add(curso);
    }

    public List<Curso> listar() {
        return cursos;
    }

    public Curso localizarPorId(String id) {
        for (Curso curso : cursos) {
            if (curso.getId().equals(id)) {
                return curso;
            }
        }

        return null;
    }

    public boolean editar(String id, String novoTitulo, String novaCategoria) {
        Curso curso = localizarPorId(id);

        if (curso != null) {
            curso.setTitulo(novoTitulo);
            curso.setCategoria(novaCategoria);
            return true;
        }

        return false;
    }

    public boolean remover(String id) {
        Curso curso = localizarPorId(id);

        if (curso != null) {
            cursos.remove(curso);
            return true;
        }

        return false;
    }

    public void ordenarPorTitulo() {
        cursos.sort(Comparator.comparing(Curso::getTitulo));
    }
}