package service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import model.Aluno;

public class AlunoService {

    private List<Aluno> alunos;

    public AlunoService() {
        alunos = new ArrayList<>();
    }

    public void cadastrar(Aluno aluno) {
        alunos.add(aluno);
    }

    public List<Aluno> listar() {
        return alunos;
    }

    public Aluno localizarPorId(String id) {
        for (Aluno aluno : alunos) {
            if (aluno.getId().equals(id)) {
                return aluno;
            }
        }

        return null;
    }

    public boolean editar(String id, String novoNome, String novaEscola) {
        Aluno aluno = localizarPorId(id);

        if (aluno != null) {
            aluno.setNomeCompleto(novoNome);
            aluno.setEscola(novaEscola);
            return true;
        }

        return false;
    }

    public boolean remover(String id) {
        Aluno aluno = localizarPorId(id);

        if (aluno != null) {
            alunos.remove(aluno);
            return true;
        }

        return false;
    }

    public void ordenarPorNome() {
        alunos.sort(Comparator.comparing(Aluno::getNomeCompleto));
    }
}