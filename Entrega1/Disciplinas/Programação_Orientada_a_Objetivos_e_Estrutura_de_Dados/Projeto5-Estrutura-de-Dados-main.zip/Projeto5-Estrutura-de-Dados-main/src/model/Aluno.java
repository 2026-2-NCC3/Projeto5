package model;

public class Aluno {

    private String id;
    private String nomeCompleto;
    private String escola;
    private String serie;
    private String anoEscolar;
    private String cidade;
    private String telefone;
    private int pontos;
    private String nivel;
    private int cursosConcluidos;
    private int faltas;
    private boolean bloqueado;

    public Aluno(String id, String nomeCompleto, String escola, String serie,
                 String anoEscolar, String cidade, String telefone,
                 int pontos, String nivel, int cursosConcluidos,
                 int faltas, boolean bloqueado) {

        this.id = id;
        this.nomeCompleto = nomeCompleto;
        this.escola = escola;
        this.serie = serie;
        this.anoEscolar = anoEscolar;
        this.cidade = cidade;
        this.telefone = telefone;
        this.pontos = pontos;
        this.nivel = nivel;
        this.cursosConcluidos = cursosConcluidos;
        this.faltas = faltas;
        this.bloqueado = bloqueado;
    }

    public String getId() {
        return id;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public String getEscola() {
        return escola;
    }

    public String getSerie() {
        return serie;
    }

    public String getAnoEscolar() {
        return anoEscolar;
    }

    public String getCidade() {
        return cidade;
    }

    public String getTelefone() {
        return telefone;
    }

    public int getPontos() {
        return pontos;
    }

    public String getNivel() {
        return nivel;
    }

    public int getCursosConcluidos() {
        return cursosConcluidos;
    }

    public int getFaltas() {
        return faltas;
    }

    public boolean isBloqueado() {
        return bloqueado;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public void setEscola(String escola) {
        this.escola = escola;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public void setAnoEscolar(String anoEscolar) {
        this.anoEscolar = anoEscolar;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public void setCursosConcluidos(int cursosConcluidos) {
        this.cursosConcluidos = cursosConcluidos;
    }

    public void setFaltas(int faltas) {
        this.faltas = faltas;
    }

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }
}