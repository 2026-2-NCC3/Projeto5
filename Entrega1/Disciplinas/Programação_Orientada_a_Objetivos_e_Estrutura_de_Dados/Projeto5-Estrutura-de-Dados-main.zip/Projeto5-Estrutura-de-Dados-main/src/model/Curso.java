package model;

public class Curso {

    private String id;
    private String titulo;
    private String descricao;
    private String local;
    private String dataCurso;
    private String horarioFim;
    private int vagasTotais;
    private int vagasDisponiveis;
    private int pontosOferecidos;
    private boolean possuiCertificado;
    private String categoria;
    private boolean ativo;

    public Curso(String id, String titulo, String descricao, String local,
                 String dataCurso, String horarioFim, int vagasTotais,
                 int vagasDisponiveis, int pontosOferecidos,
                 boolean possuiCertificado, String categoria, boolean ativo) {

        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.local = local;
        this.dataCurso = dataCurso;
        this.horarioFim = horarioFim;
        this.vagasTotais = vagasTotais;
        this.vagasDisponiveis = vagasDisponiveis;
        this.pontosOferecidos = pontosOferecidos;
        this.possuiCertificado = possuiCertificado;
        this.categoria = categoria;
        this.ativo = ativo;
    }

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getLocal() {
        return local;
    }

    public String getDataCurso() {
        return dataCurso;
    }

    public String getHorarioFim() {
        return horarioFim;
    }

    public int getVagasTotais() {
        return vagasTotais;
    }

    public int getVagasDisponiveis() {
        return vagasDisponiveis;
    }

    public int getPontosOferecidos() {
        return pontosOferecidos;
    }

    public boolean isPossuiCertificado() {
        return possuiCertificado;
    }

    public String getCategoria() {
        return categoria;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public void setDataCurso(String dataCurso) {
        this.dataCurso = dataCurso;
    }

    public void setHorarioFim(String horarioFim) {
        this.horarioFim = horarioFim;
    }

    public void setVagasTotais(int vagasTotais) {
        this.vagasTotais = vagasTotais;
    }

    public void setVagasDisponiveis(int vagasDisponiveis) {
        this.vagasDisponiveis = vagasDisponiveis;
    }

    public void setPontosOferecidos(int pontosOferecidos) {
        this.pontosOferecidos = pontosOferecidos;
    }

    public void setPossuiCertificado(boolean possuiCertificado) {
        this.possuiCertificado = possuiCertificado;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
}