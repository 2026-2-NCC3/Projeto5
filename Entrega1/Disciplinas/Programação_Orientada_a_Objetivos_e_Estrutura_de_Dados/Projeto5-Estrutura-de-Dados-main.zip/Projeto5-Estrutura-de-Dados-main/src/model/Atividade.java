package model;

public class Atividade {

    private String id;
    private String titulo;
    private String descricao;
    private Curso curso;
    private String data;
    private String horario;

    public Atividade(String id, String titulo, String descricao,
                     Curso curso, String data, String horario) {

        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.curso = curso;
        this.data = data;
        this.horario = horario;
    }

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public Curso getCurso() {
        return curso;
    }

    public String getData() {
        return data;
    }

    public String getHorario() {
        return horario;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
}