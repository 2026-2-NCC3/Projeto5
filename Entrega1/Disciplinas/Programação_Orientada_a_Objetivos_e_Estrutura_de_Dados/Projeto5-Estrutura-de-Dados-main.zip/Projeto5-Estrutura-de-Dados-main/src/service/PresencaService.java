package service;

import java.util.ArrayList;
import java.util.List;

import model.Presenca;

public class PresencaService {

    private List<Presenca> presencas;

    public PresencaService() {
        presencas = new ArrayList<>();
    }

    public void cadastrar(Presenca presenca) {
        presencas.add(presenca);
    }

    public List<Presenca> listar() {
        return presencas;
    }

    public Presenca localizarPorId(String id) {
        for (Presenca presenca : presencas) {
            if (presenca.getId().equals(id)) {
                return presenca;
            }
        }

        return null;
    }

    public boolean editar(String id, boolean novaPresenca) {
        Presenca presenca = localizarPorId(id);

        if (presenca != null) {
            presenca.setPresente(novaPresenca);
            return true;
        }

        return false;
    }

    public boolean remover(String id) {
        Presenca presenca = localizarPorId(id);

        if (presenca != null) {
            presencas.remove(presenca);
            return true;
        }

        return false;
    }
}