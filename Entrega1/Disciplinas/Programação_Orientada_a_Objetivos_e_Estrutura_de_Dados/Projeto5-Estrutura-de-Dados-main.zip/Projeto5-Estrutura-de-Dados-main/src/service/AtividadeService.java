package service;

import java.util.ArrayList;
import java.util.List;

import model.Atividade;

public class AtividadeService {

    private List<Atividade> atividades;

    public AtividadeService() {
        atividades = new ArrayList<>();
    }

    public void cadastrar(Atividade atividade) {
        atividades.add(atividade);
    }

    public List<Atividade> listar() {
        return atividades;
    }

    public Atividade localizarPorId(String id) {
        for (Atividade atividade : atividades) {
            if (atividade.getId().equals(id)) {
                return atividade;
            }
        }

        return null;
    }

    public boolean editar(String id, String novoTitulo, String novaDescricao) {
        Atividade atividade = localizarPorId(id);

        if (atividade != null) {
            atividade.setTitulo(novoTitulo);
            atividade.setDescricao(novaDescricao);
            return true;
        }

        return false;
    }

    public boolean remover(String id) {
        Atividade atividade = localizarPorId(id);

        if (atividade != null) {
            atividades.remove(atividade);
            return true;
        }

        return false;
    }
}